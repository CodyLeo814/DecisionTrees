#decision tree
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
dataset=pd.read_csv("C:Downloads\datascienceinfo\high_diamond_ranked_10min.csv")

X=dataset.drop('blueWins',axis=1)
y=dataset['blueWins']
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=.20)
from sklearn.tree import DecisionTreeClassifier
classify=DecisionTreeClassifier()
classify.fit(X_train,y_train)
y_pred=classify.predict(X_test)
from sklearn import metrics
from sklearn.metrics import classification_report, confusion_matrix
print ("Accuracy: ", metrics.accuracy_score(y_test,y_pred))
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
dataset.describe()
from sklearn.tree import DecisionTreeRegressor
R=DecisionTreeRegressor()
R.fit(X_train,y_train)
y_pred=R.predict(X_test)
df=pd.DataFrame({'Actual':y_test,'Predict': y_pred})
df
from sklearn import metrics
print('Mean absolute Error: ',metrics.mean_absolute_error(y_test,y_pred))
print('Mean Squared Error: ',metrics.mean_squared_error(y_test,y_pred))
print('Root Mean Squared Error: ',np.sqrt(metrics.mean_squared_error(y_test,y_pred)))
